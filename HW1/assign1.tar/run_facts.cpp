#include <iostream>
#include <stdlib.h>
#include <string>

using namespace std;

#include "state_facts.h"


int main(int argc, char *argv [])
{

  is_valid_arguments(argc, argv);

  return 0;
}
